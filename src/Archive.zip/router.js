export default {
    logIn: require('./pages/LoginPage'),
    collect: require('./pages/CollectPage'),
    logout: require('./pages/LogoutPage')
};