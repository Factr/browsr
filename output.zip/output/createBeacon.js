// Content script
let beacon = document.createElement("div");
// Set random string for className to avoid collision
beacon.className = "eyda3905myu";
document.body.appendChild(beacon);
